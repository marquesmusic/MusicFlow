# MusicFlow 1.0 — Android + iPhone

Projeto Flutter multiplataforma preparado para pesquisa de vídeos do YouTube, reprodução, favoritos, histórico, compartilhamento e downloads **somente de mídia que o seu backend/catálogo tenha autorização para distribuir**.

## O que já está implementado
- UI Material 3 escura, responsiva para celular.
- Pesquisa real via YouTube Data API v3 através do backend.
- Player oficial do YouTube dentro do app.
- Favoritos e histórico persistentes no aparelho.
- Compartilhamento e abertura do vídeo no YouTube.
- Download de áudio/vídeo autorizado pelo seu próprio servidor/CDN.
- Ícone vetorial em `assets/musicflow_icon.svg`.
- Backend Node/Express com `/health`, `/search` e `/download`.

## Importante sobre downloads
O app não extrai/ripa streams do YouTube. A Apple proíbe apps de salvar/converter/baixar mídia de serviços de terceiros sem autorização explícita; portanto, para publicar com segurança, conecte `/download` a um catálogo próprio/licenciado. Consulte as diretrizes da App Store antes da submissão.

## Gerar as pastas Android/iOS
Este ambiente não possui Flutter/Xcode instalados, então os diretórios nativos não foram compilados aqui. Em um computador com Flutter instalado:

```bash
cd musicflow_app
./scripts/bootstrap.sh
```

Isso executa `flutter create .` e gera `android/` e `ios/` sem apagar `lib/` e `pubspec.yaml`.

## Backend

```bash
cd server
npm install
cp .env.example .env
# edite YOUTUBE_API_KEY
npm start
```

Produção: use HTTPS e configure `CORS_ORIGIN`.

## Android
Emulador:
```bash
flutter run --dart-define=API_BASE_URL=http://10.0.2.2:3000
```

Celular físico:
```bash
flutter run --dart-define=API_BASE_URL=http://IP_DO_SERVIDOR:3000
```

Release para Google Play:
```bash
flutter build appbundle --release --dart-define=API_BASE_URL=https://api.seudominio.com
```
O AAB fica em `build/app/outputs/bundle/release/`.

## iPhone
É necessário macOS + Xcode para assinar e publicar iOS. Abra `ios/Runner.xcworkspace`, defina Bundle Identifier, equipe de assinatura e ícones. Depois:

```bash
flutter build ipa --release --dart-define=API_BASE_URL=https://api.seudominio.com
```
O IPA fica em `build/ios/ipa/`.

## Publicação
- Google Play: enviar AAB pelo Play Console.
- Apple: enviar IPA pelo Xcode/Transporter para App Store Connect e testar via TestFlight.
- Criar página de privacidade, suporte e metadados finais antes do envio.
- Não usar nome/ícone/marca de terceiros sem autorização.

## Próxima etapa de produto
Para virar um serviço comercial completo, recomendo adicionar autenticação, playlists sincronizadas, catálogo licenciado, CDN, painel administrativo, analytics, assinatura e anúncios, além de política de privacidade e termos de uso.
