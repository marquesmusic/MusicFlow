import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:youtube_player_iframe/youtube_player_iframe.dart';

const apiBaseUrl = String.fromEnvironment('API_BASE_URL', defaultValue: 'http://10.0.2.2:3000');

void main() => runApp(const MusicFlowApp());

class VideoItem {
  final String id, title, channel, thumbnail;
  const VideoItem({required this.id, required this.title, required this.channel, required this.thumbnail});
  factory VideoItem.fromJson(Map<String, dynamic> j) => VideoItem(id: j['id'], title: j['title'], channel: j['channel'], thumbnail: j['thumbnail']);
  Map<String, dynamic> toJson() => {'id': id, 'title': title, 'channel': channel, 'thumbnail': thumbnail};
}

class Api {
  static Future<List<VideoItem>> search(String q) async {
    final r = await http.get(Uri.parse('$apiBaseUrl/search?q=${Uri.encodeQueryComponent(q)}')).timeout(const Duration(seconds: 15));
    if (r.statusCode != 200) throw Exception('Falha na pesquisa.');
    return (jsonDecode(r.body) as List).map((e) => VideoItem.fromJson(e)).toList();
  }
  static Future<String?> authorizedDownloadUrl(String id, String format) async {
    final r = await http.post(Uri.parse('$apiBaseUrl/download'), headers: {'content-type': 'application/json'}, body: jsonEncode({'videoId': id, 'format': format})).timeout(const Duration(seconds: 15));
    if (r.statusCode != 200) return null;
    return (jsonDecode(r.body) as Map)['url'] as String?;
  }
}

class LibraryStore extends ChangeNotifier {
  static const _favoritesKey = 'favorites';
  static const _historyKey = 'history';
  List<VideoItem> favorites = [];
  List<VideoItem> history = [];

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    favorites = _decode(p.getStringList(_favoritesKey));
    history = _decode(p.getStringList(_historyKey));
    notifyListeners();
  }
  List<VideoItem> _decode(List<String>? list) => (list ?? []).map((s) => VideoItem.fromJson(jsonDecode(s))).toList();
  Future<void> _save(String key, List<VideoItem> value) async { final p = await SharedPreferences.getInstance(); await p.setStringList(key, value.map((v) => jsonEncode(v.toJson())).toList()); }
  bool isFavorite(String id) => favorites.any((v) => v.id == id);
  Future<void> toggleFavorite(VideoItem v) async { if (isFavorite(v.id)) { favorites.removeWhere((x) => x.id == v.id); } else { favorites.insert(0, v); } await _save(_favoritesKey, favorites); notifyListeners(); }
  Future<void> addHistory(VideoItem v) async { history.removeWhere((x) => x.id == v.id); history.insert(0, v); if (history.length > 30) history = history.take(30).toList(); await _save(_historyKey, history); notifyListeners(); }
}

class MusicFlowApp extends StatefulWidget { const MusicFlowApp({super.key}); @override State<MusicFlowApp> createState() => _MusicFlowAppState(); }
class _MusicFlowAppState extends State<MusicFlowApp> {
  final store = LibraryStore();
  @override void initState() { super.initState(); store.load(); }
  @override void dispose() { store.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => AnimatedBuilder(animation: store, builder: (_, __) => MaterialApp(
    debugShowCheckedModeBanner: false, title: 'MusicFlow', theme: ThemeData.dark(useMaterial3: true).copyWith(
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF7C4DFF), brightness: Brightness.dark), scaffoldBackgroundColor: const Color(0xFF08080C),
      cardTheme: const CardThemeData(color: Color(0xFF14141B), elevation: 0), inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: const Color(0xFF17171F), border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(18)), borderSide: BorderSide.none)),
    ), home: HomeShell(store: store),
  ));
}

class HomeShell extends StatefulWidget { final LibraryStore store; const HomeShell({super.key, required this.store}); @override State<HomeShell> createState() => _HomeShellState(); }
class _HomeShellState extends State<HomeShell> {
  int tab = 0;
  @override Widget build(BuildContext context) => Scaffold(
    body: IndexedStack(index: tab, children: [SearchPage(store: widget.store), LibraryPage(store: widget.store), const AboutPage()]),
    bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (i) => setState(() => tab = i), destinations: const [NavigationDestination(icon: Icon(Icons.search), label: 'Pesquisar'), NavigationDestination(icon: Icon(Icons.library_music_outlined), label: 'Biblioteca'), NavigationDestination(icon: Icon(Icons.info_outline), label: 'Sobre')]),
  );
}

class SearchPage extends StatefulWidget { final LibraryStore store; const SearchPage({super.key, required this.store}); @override State<SearchPage> createState() => _SearchPageState(); }
class _SearchPageState extends State<SearchPage> {
  final controller = TextEditingController(); List<VideoItem> results = []; bool loading = false; String? error;
  Future<void> search() async { final q = controller.text.trim(); if (q.isEmpty) return; FocusScope.of(context).unfocus(); setState(() { loading = true; error = null; }); try { results = await Api.search(q); } catch (e) { error = 'Não foi possível pesquisar. Verifique a API e sua conexão.'; } if (mounted) setState(() => loading = false); }
  @override Widget build(BuildContext context) => SafeArea(child: CustomScrollView(slivers: [SliverAppBar.large(title: const Text('MusicFlow'), actions: [IconButton(onPressed: () => setState(() { results = []; controller.clear(); }), icon: const Icon(Icons.refresh))]), SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 16), child: TextField(controller: controller, onSubmitted: (_) => search(), textInputAction: TextInputAction.search, decoration: InputDecoration(prefixIcon: const Icon(Icons.search), hintText: 'Música, artista ou vídeo', suffixIcon: IconButton(onPressed: search, icon: const Icon(Icons.arrow_forward)))))), if (loading) const SliverToBoxAdapter(child: LinearProgressIndicator(minHeight: 2)), if (error != null) SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.all(24), child: Text(error!, textAlign: TextAlign.center))), if (results.isEmpty && !loading && error == null) const SliverFillRemaining(hasScrollBody: false, child: Center(child: Padding(padding: EdgeInsets.all(30), child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.music_note_rounded, size: 72), SizedBox(height: 12), Text('Pesquise para encontrar vídeos do YouTube', textAlign: TextAlign.center)])))), if (results.isNotEmpty) SliverPadding(padding: const EdgeInsets.all(16), sliver: SliverList.separated(itemCount: results.length, separatorBuilder: (_, __) => const SizedBox(height: 10), itemBuilder: (_, i) => ResultCard(item: results[i], store: widget.store)))]));
}

class ResultCard extends StatelessWidget { final VideoItem item; final LibraryStore store; const ResultCard({super.key, required this.item, required this.store}); @override Widget build(BuildContext context) => Card(child: InkWell(borderRadius: BorderRadius.circular(16), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PlayerPage(item: item, store: store))), child: Padding(padding: const EdgeInsets.all(10), child: Row(children: [ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.network(item.thumbnail, width: 128, height: 76, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(width: 128, height: 76, color: Colors.black26, child: const Icon(Icons.music_note)))), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(item.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)), const SizedBox(height: 5), Text(item.channel, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.grey[400])), const SizedBox(height: 7), const Row(children: [Icon(Icons.play_circle_outline, size: 18), SizedBox(width: 5), Text('Abrir player')])]))])))); }

class LibraryPage extends StatelessWidget { final LibraryStore store; const LibraryPage({super.key, required this.store}); @override Widget build(BuildContext context) => DefaultTabController(length: 2, child: SafeArea(child: Column(children: [const SizedBox(height: 16), const Text('Biblioteca', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)), const SizedBox(height: 10), const TabBar(tabs: [Tab(text: 'Favoritos'), Tab(text: 'Histórico')]), Expanded(child: TabBarView(children: [_list(context, store.favorites, store), _list(context, store.history, store)]))]))); }
Widget _list(BuildContext context, List<VideoItem> items, LibraryStore store) => items.isEmpty ? const Center(child: Text('Nada por aqui ainda.')) : ListView.separated(padding: const EdgeInsets.all(16), itemCount: items.length, separatorBuilder: (_, __) => const SizedBox(height: 8), itemBuilder: (_, i) => ResultCard(item: items[i], store: store));

class PlayerPage extends StatefulWidget { final VideoItem item; final LibraryStore store; const PlayerPage({super.key, required this.item, required this.store}); @override State<PlayerPage> createState() => _PlayerPageState(); }
class _PlayerPageState extends State<PlayerPage> {
  late final YoutubePlayerController controller; bool downloading = false;
  @override void initState() { super.initState(); controller = YoutubePlayerController.fromVideoId(videoId: widget.item.id, autoPlay: false, params: const YoutubePlayerParams(showFullscreenButton: true, showVideoAnnotations: false, privacyEnhancedMode: true)); widget.store.addHistory(widget.item); }
  @override void dispose() { controller.close(); super.dispose(); }
  Future<void> downloadAuthorized(String format) async { setState(() => downloading = true); try { final url = await Api.authorizedDownloadUrl(widget.item.id, format); if (url == null) throw Exception('Este conteúdo não possui download autorizado.'); final res = await http.get(Uri.parse(url)).timeout(const Duration(minutes: 2)); if (res.statusCode != 200) throw Exception('Download falhou.'); final dir = Platform.isAndroid ? (await getExternalStorageDirectory() ?? await getApplicationDocumentsDirectory()) : await getApplicationDocumentsDirectory(); final safeTitle = widget.item.title.replaceAll(RegExp(r'[^a-zA-Z0-9 _-]'), '_').trim(); final safe = safeTitle.isEmpty ? widget.item.id : safeTitle.substring(0, safeTitle.length > 80 ? 80 : safeTitle.length); final ext = format == 'audio' ? 'mp3' : 'mp4'; final file = File('${dir.path}/$safe.$ext'); await file.writeAsBytes(res.bodyBytes); if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Arquivo salvo no armazenamento do app.'))); } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()))); } finally { if (mounted) setState(() => downloading = false); } }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Player')), body: ListView(padding: const EdgeInsets.all(16), children: [YoutubePlayer(controller: controller, aspectRatio: 16 / 9), const SizedBox(height: 18), Text(widget.item.title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)), const SizedBox(height: 6), Text(widget.item.channel, style: TextStyle(color: Colors.grey[400])), const SizedBox(height: 20), Row(children: [Expanded(child: FilledButton.icon(onPressed: downloading ? null : () => downloadAuthorized('audio'), icon: const Icon(Icons.download), label: const Text('Áudio'))), const SizedBox(width: 10), Expanded(child: OutlinedButton.icon(onPressed: downloading ? null : () => downloadAuthorized('video'), icon: const Icon(Icons.video_file_outlined), label: const Text('Vídeo')))]), const SizedBox(height: 10), Row(children: [Expanded(child: OutlinedButton.icon(onPressed: () async { final u = Uri.parse('https://www.youtube.com/watch?v=${widget.item.id}'); await launchUrl(u, mode: LaunchMode.externalApplication); }, icon: const Icon(Icons.open_in_new), label: const Text('YouTube'))), const SizedBox(width: 10), Expanded(child: OutlinedButton.icon(onPressed: () => SharePlus.instance.share(ShareParams(text: 'https://www.youtube.com/watch?v=${widget.item.id}')), icon: const Icon(Icons.share), label: const Text('Compartilhar')))]), const SizedBox(height: 16), Row(children: [IconButton(onPressed: () => widget.store.toggleFavorite(widget.item), icon: Icon(widget.store.isFavorite(widget.item.id) ? Icons.favorite : Icons.favorite_border)), Text(widget.store.isFavorite(widget.item.id) ? 'Favorito' : 'Adicionar aos favoritos')]), const SizedBox(height: 12), Text('Downloads funcionam somente para arquivos que o seu servidor/catálogo fornece com autorização para distribuição.', style: TextStyle(color: Colors.grey[500], fontSize: 12))]));
}

class AboutPage extends StatelessWidget { const AboutPage({super.key}); @override Widget build(BuildContext context) => SafeArea(child: ListView(padding: const EdgeInsets.all(24), children: [const Icon(Icons.graphic_eq, size: 70), const SizedBox(height: 12), const Center(child: Text('MusicFlow', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900))), const SizedBox(height: 18), const Text('Seu hub de música e vídeo: pesquisa no YouTube, reprodução, favoritos, histórico e downloads autorizados.', textAlign: TextAlign.center), const SizedBox(height: 28), const ListTile(leading: Icon(Icons.search), title: Text('Pesquisa via YouTube Data API'), subtitle: Text('Resultados reais do YouTube.')), const ListTile(leading: Icon(Icons.play_circle), title: Text('Player integrado'), subtitle: Text('Reprodução pelo player oficial.')), const ListTile(leading: Icon(Icons.download), title: Text('Downloads autorizados'), subtitle: Text('Arquivos próprios/licenciados fornecidos pela sua API.')), const SizedBox(height: 20), Text('Versão 1.0.0', style: TextStyle(color: Colors.grey))])); }
