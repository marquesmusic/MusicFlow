import 'dotenv/config';
import express from 'express';
import cors from 'cors';

const app = express();
app.use(cors({ origin: process.env.CORS_ORIGIN || '*' }));
app.use(express.json({ limit: '1mb' }));
const PORT = process.env.PORT || 3000;
const KEY = process.env.YOUTUBE_API_KEY;

app.get('/health', (_, res) => res.json({ ok: true, app: 'MusicFlow', version: '1.0.0' }));

app.get('/search', async (req, res) => {
  try {
    if (!KEY) return res.status(500).json({ error: 'Configure YOUTUBE_API_KEY no servidor.' });
    const q = String(req.query.q || '').trim();
    if (!q) return res.json([]);
    const u = new URL('https://www.googleapis.com/youtube/v3/search');
    u.searchParams.set('part', 'snippet'); u.searchParams.set('q', q); u.searchParams.set('type', 'video'); u.searchParams.set('maxResults', '20'); u.searchParams.set('key', KEY);
    const r = await fetch(u); const data = await r.json();
    if (!r.ok) return res.status(r.status).json(data);
    res.json((data.items || []).filter(x => x.id?.videoId).map(x => ({ id: x.id.videoId, title: x.snippet.title, channel: x.snippet.channelTitle, thumbnail: x.snippet.thumbnails?.high?.url || x.snippet.thumbnails?.medium?.url || x.snippet.thumbnails?.default?.url })));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Authorized catalog only. Do not extract/rip YouTube streams.
// Set AUTHORIZED_AUDIO_<videoId> / AUTHORIZED_VIDEO_<videoId> to direct files you own/license.
app.post('/download', (req, res) => {
  const { videoId, format } = req.body || {};
  if (!videoId || !['audio', 'video'].includes(format)) return res.status(400).json({ error: 'Parâmetros inválidos.' });
  const url = process.env[`AUTHORIZED_${format.toUpperCase()}_${videoId}`] || null;
  if (!url) return res.status(403).json({ error: 'Download não autorizado para este item.' });
  res.json({ url });
});

app.listen(PORT, () => console.log(`MusicFlow API on :${PORT}`));
