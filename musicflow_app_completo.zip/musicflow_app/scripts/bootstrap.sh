#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v flutter >/dev/null || { echo 'Flutter não encontrado. Instale o Flutter SDK primeiro.'; exit 1; }
flutter create .
flutter pub get
echo 'Projeto nativo Android/iOS criado. Próximo passo: configurar API_BASE_URL e assinatura.'
